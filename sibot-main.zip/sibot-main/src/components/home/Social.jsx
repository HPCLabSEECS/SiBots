import React from 'react'

const Social = () => {
  return (
    <div className="home__social">

    </div>
  )
}

export default Social